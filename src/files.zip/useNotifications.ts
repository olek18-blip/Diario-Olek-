import { useState, useEffect, useCallback, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';

export const useNotifications = () => {
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const { toast } = useToast();
  // Track scheduled timeouts so we can clean them up
  const timeoutsRef = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());

  useEffect(() => {
    if ('Notification' in window) {
      setPermission(Notification.permission);
    }
    // Cleanup all timeouts on unmount
    return () => {
      timeoutsRef.current.forEach(id => clearTimeout(id));
      timeoutsRef.current.clear();
    };
  }, []);

  const requestPermission = useCallback(async () => {
    if (!('Notification' in window)) {
      toast({
        title: "Notificaciones no soportadas",
        description: "Tu navegador no soporta notificaciones push.",
        variant: "destructive",
      });
      return false;
    }

    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      
      if (result === 'granted') {
        toast({
          title: "¡Notificaciones activadas!",
          description: "Te avisaremos de tus eventos próximos.",
        });
        return true;
      } else {
        toast({
          title: "Notificaciones bloqueadas",
          description: "Puedes habilitarlas en la configuración del navegador.",
          variant: "destructive",
        });
        return false;
      }
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      return false;
    }
  }, [toast]);

  const sendNotification = useCallback((title: string, options?: NotificationOptions) => {
    if (permission !== 'granted') return null;

    try {
      const notification = new Notification(title, {
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        ...options,
      });

      notification.onclick = () => {
        window.focus();
        notification.close();
      };

      return notification;
    } catch (error) {
      console.error('Error sending notification:', error);
      return null;
    }
  }, [permission]);

  const scheduleEventReminder = useCallback((
    eventTitle: string,
    eventDate: Date,
    reminderMinutes: number = 60
  ) => {
    const key = `event-${eventTitle}-${eventDate.getTime()}`;

    // Avoid duplicate timers for the same event
    if (timeoutsRef.current.has(key)) return;

    const now = new Date();
    const timeDiff = eventDate.getTime() - now.getTime();
    const reminderTime = timeDiff - reminderMinutes * 60 * 1000;

    if (reminderTime <= 0) return;

    const label =
      reminderMinutes >= 1440
        ? `${Math.floor(reminderMinutes / 1440)} día(s)`
        : reminderMinutes >= 60
        ? `${Math.floor(reminderMinutes / 60)} hora(s)`
        : `${reminderMinutes} minutos`;

    const timeoutId = setTimeout(() => {
      sendNotification(`📅 Recordatorio: ${eventTitle}`, {
        body: `Tu evento es en ${label}`,
        tag: key,
      });
      timeoutsRef.current.delete(key);
    }, reminderTime);

    timeoutsRef.current.set(key, timeoutId);
  }, [sendNotification]);

  const cancelReminder = useCallback((eventTitle: string, eventDate: Date) => {
    const key = `event-${eventTitle}-${eventDate.getTime()}`;
    const timeoutId = timeoutsRef.current.get(key);
    if (timeoutId !== undefined) {
      clearTimeout(timeoutId);
      timeoutsRef.current.delete(key);
    }
  }, []);

  return {
    permission,
    isSupported: 'Notification' in window,
    requestPermission,
    sendNotification,
    scheduleEventReminder,
    cancelReminder,
  };
};
