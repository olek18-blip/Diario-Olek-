import { useLocation, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { BookOpen, Home } from "lucide-react";

const NotFound = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    console.error("404 Error: Ruta no encontrada:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <div className="text-center px-6">
        <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-muted flex items-center justify-center">
          <BookOpen className="w-10 h-10 text-muted-foreground" />
        </div>
        <h1 className="mb-2 text-6xl font-serif font-bold text-foreground">404</h1>
        <p className="mb-2 text-xl text-foreground font-medium">Página no encontrada</p>
        <p className="mb-8 text-muted-foreground text-sm">
          La página que buscas no existe o fue movida.
        </p>
        <button
          onClick={() => navigate("/")}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors"
        >
          <Home className="w-4 h-4" />
          Volver al inicio
        </button>
      </div>
    </div>
  );
};

export default NotFound;
